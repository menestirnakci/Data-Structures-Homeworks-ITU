/* @Author
Student Name: Muhammed Enes Tırnakçı
Student ID : 150160038
Date: 8.12.2018 */

#include <iostream>
#include <fstream>
#include <sstream>


using namespace std;

typedef int QueueDataType;
typedef int StackDataType;

struct QueueNode{
    QueueDataType number;
    QueueNode *next;
};

struct StackNode{
    StackDataType holes;
    StackNode *next;
};

struct stackAnt{
    StackNode *top;
    void create();
    void push(StackDataType);
    StackDataType pop();
};

void stackAnt::create() {
    top = NULL;
}

void stackAnt::push(StackDataType hole) {
    StackNode *newNode = new StackNode;
    // Adding new elements to top of stack
    newNode->holes = hole;
    newNode->next = top;
    top = newNode;
}

StackDataType stackAnt::pop() {
    StackNode *topNode;
    StackDataType temp;
    //Deleting nodes from the top of the stack
    topNode = top;
    top = top->next;
    temp = topNode->holes;
    delete topNode;
    return temp; // Returning deleted node
}

struct queueAnt{
    QueueNode *front;
    QueueNode *back;
    int count ; // Number of ants
    void create();
    void enqueue(QueueDataType);
    QueueDataType dequeue();
    bool is_empty();
};

void queueAnt::create() {
    front = NULL;
    back = NULL;
}

void queueAnt::enqueue(QueueDataType newNumber) {
    QueueNode *newNode = new QueueNode;
    newNode->number = newNumber;
    newNode->next = NULL;

    if(is_empty()){ // Adding first element
        back = newNode;
        front = back;
    }
    else{ // Adding elements to and of the queue
        back->next = newNode;
        back = newNode;
    }
}

QueueDataType queueAnt::dequeue() {
    QueueNode *topNode;
    QueueDataType temp;
    //Deleting nodes from the front of the queue
    topNode = front;
    front = front->next;
    temp = topNode->number;
    delete topNode;
    return temp; // Returning deleted node
}

bool queueAnt::is_empty() {
    return front == NULL;
}

struct Ants {
    queueAnt ants ; // Queue of ants
    queueAnt holeDepths ; // Queue of hole depths
    stackAnt hole ; // Stack of holes
    void ReadFile ( char *);
    void ShowContents ( bool );
    void CrossRoad ();
};

void Ants::ReadFile(char *file) {

    string lines; // Lines of file
    ifstream antFile(file);
    antFile.is_open(); // File opened

    getline(antFile, lines); // Getting first line
    istringstream isstring1row(lines); // Reading string that is first row
    ants.create(); // Creating queue of ants
    isstring1row >> ants.count; // Getting how many ants from file as input

    for(int i = 1; i < (ants.count) +1; i++ ){ //
        ants.enqueue(i); // Pushing ants to queue
    }

    getline(antFile, lines); // Getting second line from file
    holeDepths.create(); // Creating queue of holes depths
    holeDepths.count = 0;
    istringstream isstring2row(lines); // Reading string that is first second
    string value2row; // Temporary hole-depth string

    while(getline(isstring2row,value2row,' ')){ // Splitting elements from spaces
        int num = 0;
        stringstream numbers(value2row); // Copying numbers to value2row
        numbers >> num; // Getting depth of holes from second row number by number
        holeDepths.enqueue(num); // Holes depths are pushing to queue
        holeDepths.count++; // Finding how many holes
    }

    antFile.close();
}

void Ants::ShowContents(bool toShow) {
    QueueNode *traverse;

    if(toShow == 1){ // Ant sequence
        traverse = ants.front; // Traverse is assigned to front of queue
        for(int i = 0; i < ants.count; i++){ // Number of ants times printing
            cout << traverse->number << " "; // Printing ant sequence
            traverse = traverse->next; // Traversing
        }
        cout << endl;
    }
    else if (toShow == 0){ // Holes
        traverse = holeDepths.front; // Traverse is assigned to front of queue
        for(int i = 0; i < holeDepths.count ;i++){ // Number of holes times printing
            cout << traverse->number << " "; // Printing the depth of holes
            traverse = traverse->next; // Traversing
        }
        cout << endl;
    }
}

void Ants::CrossRoad() {
    hole.create();

    for(int i = 0; i < holeDepths.count;i++){ // Number of holes times doing loop
        int goStack = holeDepths.front->number; // Depth of hole
        for(int j = 0; j < goStack;j++){ // Pushing ants to stack from queue
            hole.push(ants.dequeue()); // Ants go to hole from sequence
        }
        for(int k = 0; k < goStack;k++){ // Pushing ants to queue from stack
            ants.enqueue(hole.pop()); // Ants go to ant sequence from hole
        }
        holeDepths.dequeue(); // In order to pass next hole removing element from queue
    }
}


int main (int argc , char ** argv ){
    Ants a;
    a. ReadFile ( argv [1]); // store the number of ants and depths of holes
    cout << "The initial Ant sequence is: ";
    a. ShowContents (1); // list ant sequence ( initially : 1, 2, ... , N)
    cout << "The depth of holes are: ";
    a. ShowContents (0); // list depth of holes
    a. CrossRoad ();
    cout << "The final Ant sequence is: ";
    a. ShowContents (1);
    return 0;
}