/* @Author
* Student Name: Muhammed Enes Tırnakçı
* Student ID : 150160038
* Date: 25.11.2018 */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#define STACKSIZE 1000

using namespace std;

typedef int StackDataType;

struct myDeck{
    StackDataType stack[STACKSIZE];
    int top;
    void create();
    StackDataType pop();
    bool isempty();
    bool push(StackDataType);
    void givingCards(myDeck &, myDeck &);
};

void myDeck::create() {
    top = 0;
}

bool myDeck::isempty() {
    return (top == 0);
}

StackDataType myDeck::pop() {
    return stack[--top];
}

bool myDeck::push(StackDataType newCard) {
    if ( top < STACKSIZE ){
        stack[top++] = newCard;
        return true;
    }
    return false;
}

void myDeck::givingCards(myDeck &person1, myDeck &person2) {

    if(person1.stack[person1.top-1] > person2.stack[person2.top-1]){ //Person 1 gives card to person 2.
        person2.push(person1.pop());
    }

}


int main(int argc, char *argv[]) {

    if(argc != 2) cout << ""; // Preventing if input file not at the command line.

    int tableDeckCount;
    int playerDeckCount;
    // Creating structs
    myDeck bin;
    myDeck person1;
    myDeck person2;
    myDeck deck;

    person1.create(); // Creating stack for first player
    person2.create(); // Creating stack for second player
    bin.create();  // Creating stack for bin
    deck.create(); // Creating stack for deck at table

    string lines;
    ifstream inputs(argv[1]); //argv[1]"C:\\Users\\Enes\\CLionProjects\\Homework3\\input.txt"

    if (!inputs.is_open()) { // Reading file if it exists
        cout << "Failed to open file " << endl;
        return 0;
    }
    inputs.is_open();
    getline(inputs,lines); // Getting first line from the input file.
    istringstream iss(lines);
    // Getting how many cards there will be in a players deck.
    // Getting how many cards there will be in the deck on the table.
	iss >> tableDeckCount >> playerDeckCount ;


    // Getting cards of deck which is at the table
    for(int i = 0; i < tableDeckCount;i++){
        getline(inputs,lines);
        string string_card;
        int card;
        if(lines.at(0) == '-') { // If the number is negative taking it as string
            unsigned int length = lines.length(); // Length of the line
            for( unsigned int h = 1; h < length ;h++){
                string_card += lines.at(h);
            }
            card = stoi(string_card) * (-1); // Converting the number to integer
        }
		// If the number is positive taking it as string
        else{
            unsigned int length = lines.length(); // Length of the line
            for(unsigned int h = 0; h < length ; h++){
                string_card += lines.at(h);
            }
            card = stoi(string_card); // Converting the number to integer
        }
        if(card != 0) deck.push(card);
        else i--;
    }

    // Getting first player's cards
    for(int i = 0; i < playerDeckCount ;i++){
        getline(inputs,lines);
        string string_card;
        int card;
        if(lines.at(0) == '-') { // (*)Firstly taking the negative number as string
            unsigned int length = lines.length(); // Length of the line
            for(unsigned int h = 1; h < length ;h++){
                string_card += lines.at(h);
            }
            card = stoi(string_card) * (-1); // (*)Secondly converting the number to integer
        }
		// (**)Firstly taking positive the number as string
        else{
            unsigned int length = lines.length(); // Length of the line
            for(unsigned int h = 0; h < length ; h++){
                string_card += lines.at(h);
            }
            card = stoi(string_card);
        }
        if(card != 0) person1.push(card); // (**)Secondly converting the number to integer
        else i--;
    }

    // Getting second player's cards
    for(int i = 0; i < playerDeckCount ;i++){
        getline(inputs,lines);
        string string_card;
        int card ;
        if(lines.at(0) == '-') { // (*)Firstly taking the negative number as string
            unsigned int length = lines.length(); // Length of the line
            for(unsigned int h = 1; h < length ;h++){
                string_card += lines.at(h);
            }
            card = stoi(string_card) * (-1); // (*)Secondly converting the number to integer
        }
		// (**)Firstly taking positive the number as string
        else{
            unsigned int length = lines.length(); // Length of the line
            for(unsigned int h = 0; h < length ; h++){
                string_card += lines.at(h);
            }
            card = stoi(string_card); // (**)Secondly converting the number to integer
        }
        if(card != 0) person2.push(card);
        else i--;
    }

    int turn = 1;
    for(int i = 0 ; i < tableDeckCount; i++) {
        if(deck.top == 0 || person1.top == 0 || person2.top == 0) break; // If deck or one the player is out of card finish the game
        bool person1gives = true;

        // First player takes card from table
        if(turn %2 == 1 ){
            if(deck.stack[deck.top -1] < 0){ // If taked card is negative, player1 will give cards amount of (the taked card * (-1)) to the other player
                person1gives = true;
            }
            else{
                person1gives = false; // If taked card is positive, player2 will take cards amount of the taked card from the other player
            }
        }
        // Second player takes card from table
        else {
            if(deck.stack[deck.top -1] < 0){ // If taked card is negative, player2 will give cards amount of (the taked card * (-1)) to the other player
                person1gives = false; // If taked card is positive, player1 will take cards amount of the taked card from the other player
            }
        }

        int how_many_will_given = deck.stack[deck.top-1];
        if(how_many_will_given < 0) how_many_will_given *= (-1); // If top of deck at table is negative making it positive
        // Preventing try to give more than cards "Example: First player has 2 cards but player taked card from table which is -3"
        if(how_many_will_given > person1.top && person1gives) how_many_will_given = person1.top; // First player gives
        else if(how_many_will_given > person2.top && !person1gives) how_many_will_given = person2.top; // Second player gives

        for (int a = 0; a < how_many_will_given  ;a++){

            if(person1gives){
                // If first player gives cards
                if(person1.stack[person1.top-1] > person2.stack[person2.top-1]){ // Card comparison between first player's and second player's top cards
                    person1.givingCards(person1,person2); // Giving card to second player
                }
                else{
                    bin.push(person1.pop()); // Person1's top card goes to bin
                }
            }
            else{
                // If second player gives cards
                if(person1.stack[person1.top-1] < person2.stack[person2.top-1]){ // Card comparison between first player's and second player's top cards
                    person2.givingCards(person2,person1); // Giving card to first player
                }
                else{
                    bin.push(person2.pop()); // Person2's top card goes to bin
                }
            }
        }
        deck.pop(); // Decreasing the deck's cards
        turn++;
    }

    cout << bin.top << endl; // Priting how many elements in bin

	inputs.close(); // Closing file

    return 0;
}