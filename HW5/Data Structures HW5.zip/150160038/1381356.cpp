/* @Author
Student Name: Muhammed Enes Tırnakçı
Student ID : 150160038
Date: <20.12.2018>*/

#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

struct listNode{ // nodes of the list
    int list_number;
    listNode *next;
    listNode *previous;
};
struct List{
    listNode *head;
    listNode *tail;
    int count;
    void create();
    void add(int);
    void remove();
};

void List::create() {
    head = NULL;
    tail = NULL;
    count = 0;
}

void List::add(int number) {

    listNode *newNode = new listNode;
    newNode->list_number = number;
    newNode->next = NULL;
    newNode->previous = NULL;

    if(head == NULL){
        head = newNode;
        tail = newNode;
        count++;
    }
    else{
        tail->next = newNode;
        newNode->previous = tail;
        tail = newNode;
        count++;
    }
}

void List::remove() {

    listNode *traverse;
    traverse = tail;
    tail = traverse->previous;
    delete traverse;
    count--;
}

struct TreeNode{
    int number;
    TreeNode *left;
    TreeNode *right;
};

struct binaryTree{
    TreeNode *root;
    List *pathL;
    List *pathR;
    bool pathFound;
    void create();
    void pathSum(TreeNode *,int, List *);
};

TreeNode *constructTree(int *arr, int size,int index, TreeNode *root) {

    if(index < size){

        TreeNode *newNode = new TreeNode;
        newNode->number = arr[index]; // Level by level addition to tree
        newNode->right = NULL;
        newNode->left = NULL;

        root = newNode;

        root->left = constructTree(arr,size,2*index+1,root->left);
        root->right = constructTree(arr,size,2*index+2,root->right);
    }
    return root;
}


void binaryTree::pathSum(TreeNode *travNode, int targetSum , List *mylist) {

    if(travNode == NULL) { // No node left
        if (targetSum == 0 && !pathFound) { // Sum is granted and first foundation of sum
            listNode *traverse = mylist->head; // Traversing list
            cout << "Path Found: ";
            for (int i = 0; i < mylist->count; i++) { // Printing path
                cout <<  traverse->list_number << " " ;
                traverse = traverse->next;
            }
            cout << endl;
            pathFound = true;
        }
        return;
    }
    else{
        int sum = targetSum - travNode->number; // Subtracting passed element from target sum
        mylist->add(travNode->number);
        if(sum == 0 && !pathFound){ // Sum is granted and first foundation of sum
            listNode *traverse = mylist->head; // Traversing list
            cout << "Path Found: ";
            for (int i = 0; i < mylist->count; i++) { // Printing path
                cout <<  traverse->list_number << " " ;
                traverse = traverse->next;
            }
            cout << endl;
            pathFound = true;
            return;
        }
        if(travNode->left){ // Traversing left part of tree
            pathSum(travNode->left, sum, mylist);
            mylist->remove();
        }
        if(travNode->right) { // Traversing right part of tree
            pathSum(travNode->right, sum, mylist);
            mylist->remove();
        }
    }
}

void binaryTree::create(){
    root = NULL;
    pathR = new List;
    pathL = new List;
    pathL->create();
    pathR->create();
    pathFound = false;
}

int main(int argc , char ** argv) {

    binaryTree Btree; // Creating tree
    Btree.create();

    int values; // Elements of tree
    int sum = 0;
    int valuesArr[10000]; // Array for tree elements
    string lines;

    ifstream treeFile(argv[1]);
    treeFile.is_open(); // Opening file

    getline(treeFile, lines); // Getting first line from file
    istringstream isstring1row(lines); // Reading first line
    string strValues; // Temporary value string

    int arrSize = 0;
    while(getline(isstring1row,strValues,' ')){ // Getting elements of trees with splitting
        stringstream numbers(strValues);
        numbers >> values; // Assigning numbers to a variable
        valuesArr[arrSize] = values; // Adding elements to tree
        arrSize++; // How many elements in tree
    }
    int index = 0;
    Btree.root = constructTree(valuesArr,arrSize, index, Btree.root); // Adding elements to tree

    getline(treeFile,lines); // Getting second line from file
    istringstream isstring2row(lines); // Reading second line which contains sum
    isstring2row >> sum; // To find a find getting need sum

    // Paths are found by these functions
    Btree.pathL->add(Btree.root->number); // Adding first element which is root to path
    Btree.pathR->add(Btree.root->number); // Adding first element which is root to path

    Btree.pathSum(Btree.root->left,sum - Btree.root->number, Btree.pathL); // Left path
    if(!Btree.pathFound) {
        cout << "No Path Found" << endl;
    }
    Btree.pathFound = false; // Resetting bool
    Btree.pathSum(Btree.root->right,sum - Btree.root->number,Btree.pathR); // Right path
    if(!Btree.pathFound) {
        cout << "No Path Found" << endl;
    }

    treeFile.close(); // Closing file
    return 0;
}
